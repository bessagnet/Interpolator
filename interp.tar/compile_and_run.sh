#/bin/bash
ifort example.F90  interporlation.F90 -o example.e
./example.e
